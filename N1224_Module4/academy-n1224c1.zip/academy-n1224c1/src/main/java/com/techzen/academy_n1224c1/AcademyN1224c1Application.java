package com.techzen.academy_n1224c1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademyN1224c1Application {

	public static void main(String[] args) {
		SpringApplication.run(AcademyN1224c1Application.class, args);
	}

}
