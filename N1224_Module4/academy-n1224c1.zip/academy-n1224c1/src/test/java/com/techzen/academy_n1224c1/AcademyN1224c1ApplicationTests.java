package com.techzen.academy_n1224c1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademyN1224c1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
